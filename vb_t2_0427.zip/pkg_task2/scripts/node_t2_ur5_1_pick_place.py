#! /usr/bin/env python

import os
import rospy
import sys
import copy
import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
import math

from gazebo_ros_link_attacher.srv import Attach, AttachRequest, AttachResponse

from pkg_vb_sim.srv import vacuumGripper
from pkg_vb_sim.srv import vacuumGripperRequest
from pkg_vb_sim.srv import vacuumGripperResponse

from pkg_vb_sim.msg import LogicalCameraImage


class Ur5Moveit:

    # Constructor
    def __init__(self):

        rospy.init_node('node_eg3_set_joint_angles', anonymous=True)

        self._planning_group = "ur5_1_planning_group"
        self._commander = moveit_commander.roscpp_initialize(sys.argv)
        self._robot = moveit_commander.RobotCommander()
        self._scene = moveit_commander.PlanningSceneInterface()
        self._group = moveit_commander.MoveGroupCommander(self._planning_group)
        self._display_trajectory_publisher = rospy.Publisher(
            '/move_group/display_planned_path',
            moveit_msgs.msg.DisplayTrajectory, queue_size=1)

        self._exectute_trajectory_client = actionlib.SimpleActionClient(
            'execute_trajectory', moveit_msgs.msg.ExecuteTrajectoryAction)
        self._exectute_trajectory_client.wait_for_server()

        self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()
        self.box_name = ''
        # Current State of the Robot is needed to add box to planning scene
        self._curr_state = self._robot.get_current_state()

        rospy.loginfo(
            '\033[94m' + "Planning Group: {}".format(self._planning_frame) +
            '\033[0m')
        rospy.loginfo(
            '\033[94m' + "End Effector Link: {}".format(self._eef_link) +
            '\033[0m')
        rospy.loginfo(
            '\033[94m' + "Group Names: {}".format(self._group_names) +
            '\033[0m')

        rospy.loginfo('\033[94m' + " >>> Ur5Moveit init done." + '\033[0m')

    def go_to_pose(self, arg_pose):

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Current Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        self._group.set_pose_target(arg_pose)
        flag_plan = self._group.go(wait=True)  # wait=False for Async Move

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Final Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Final Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        if (flag_plan is True):
            rospy.loginfo(
                '\033[94m' + ">>> go_to_pose() Success" + '\033[0m')
        else:
            rospy.logerr(
                '\033[94m' +
                ">>> go_to_pose() Failed. Solution for Pose not Found." +
                '\033[0m')

        return flag_plan

    def wait_for_state_update(self, box_is_known=False,
                              box_is_attached=False, timeout=4):
        box_name = self.box_name
        scene = self._scene
        start = rospy.get_time()
        seconds = rospy.get_time()
        while (seconds - start < timeout) and not rospy.is_shutdown():
            # Test if the box is in attached objects
            attached_objects = scene.get_attached_objects([box_name])
            is_attached = len(attached_objects.keys()) > 0
        # Test if the box is in the scene.
        # Note that attaching the box will remove it from known_objects
            is_known = box_name in scene.get_known_object_names()

        # Test if we are in the expected state
            if (box_is_attached == is_attached) and (box_is_known == is_known):
                return True

        # Sleep so that we give other threads time on the processor
            rospy.sleep(0.1)
            seconds = rospy.get_time()

    # If we exited the while loop without returning then we timed out
        return False

    def set_joint_angles(self, arg_list_joint_angles):

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Current Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        self._group.set_joint_value_target(arg_list_joint_angles)
        self._group.plan()
        flag_plan = self._group.go(wait=True)

        list_joint_values = self._group.get_current_joint_values()
        rospy.loginfo('\033[94m' + ">>> Final Joint Values:" + '\033[0m')
        rospy.loginfo(list_joint_values)

        pose_values = self._group.get_current_pose().pose
        rospy.loginfo('\033[94m' + ">>> Final Pose:" + '\033[0m')
        rospy.loginfo(pose_values)

        if (flag_plan is True):
            rospy.loginfo(
                '\033[94m' + ">>> set_joint_angles() Success" + '\033[0m')
        else:
            rospy.logerr(
                '\033[94m' + ">>> set_joint_angles() Failed." + '\033[0m')

        return flag_plan

    def go_to_predefined_pose(self, arg_pose_name):
        rospy.loginfo('\033[94m' +
                      "Going to Pose: {}".format(arg_pose_name) + '\033[0m')
        self._group.set_named_target(arg_pose_name)
        plan = self._group.plan()
        goal = moveit_msgs.msg.ExecuteTrajectoryGoal()
        goal.trajectory = plan
        self._exectute_trajectory_client.send_goal(goal)
        self._exectute_trajectory_client.wait_for_result()
        rospy.loginfo('\033[94m' +
                      "Now at Pose: {}".format(arg_pose_name) + '\033[0m')

    def add_box(self, timeout=4):
        box_name = self.box_name
        scene = self._scene

        # First, we will create a box in the planning scene in the shelfs:
        box_pose = geometry_msgs.msg.PoseStamped()
        box_pose.header.frame_id = "world"
        box_pose.pose.position.x = 0.036346
        box_pose.pose.position.y = 0.4400013
        box_pose.pose.position.z = 1.96609
        box_pose.pose.orientation.x = -0.01300
        box_pose.pose.orientation.y = 1.00000
        box_pose.pose.orientation.z = -0.00001
        box_pose.pose.orientation.w = 0.00000
        box_name = "box"
        scene.add_box(box_name, box_pose, size=(0.150, 0.150, 0.150))

        self.box_name = box_name
        return self.wait_for_state_update(box_is_known=True, timeout=timeout)

    def attach_box(self, timeout=4):
        # Now we need to attach the baox to the vacuum gripper
        box_name = self.box_name
        robot = self._robot
        scene = self._scene
        eef_link = self._eef_link
        group_names = self._group_names
        grasping_group = 'ur5_1_planning_group'
        touch_links = robot.get_link_names(group=grasping_group)
        scene.attach_box(eef_link, box_name, touch_links=touch_links)

        # Vacuum Gripper service to activate/deactiavte the gripper
        vacuumGripperService = '/eyrc/vb/ur5_1/activate_vacuum_gripper'
        
        # Waiting for the vacuum gripper service to become active
        rospy.wait_for_service(vacuumGripperService)

        # Creating a object of vacuumGripper service (message) to
        # call the service with the message to activate the vacuum gripper
        vacuum_Gripper = rospy.ServiceProxy(vacuumGripperService,
                                            vacuumGripper)
        # Sending the service call throough a try - catch block so that
        # a failure to call will be intimated to the user
        try:
            resp = vacuum_Gripper(activate_vacuum_gripper=True)
        except rospy.ServiceException as exc:
            print("Service did not process request: " + str(exc))
        print("\nVacuum gripper activated.\n")

        # We wait for the planning scene to update.
        return self.wait_for_state_update(box_is_attached=True,
                                          box_is_known=False,
                                          timeout=timeout)

    def detach_and_remove_box(self, timeout=4):
        box_name = self.box_name
        scene = self._scene
        eef_link = self._eef_link

        # Vacuum Gripper service to activate/deactiavte the gripper
        vacuumGripperService = '/eyrc/vb/ur5_1/activate_vacuum_gripper'

        # Waiting for the vacuum gripper service to become active
        rospy.wait_for_service(vacuumGripperService)

        # Creating a object of vacuumGripper service (message) to
        # call the service with the message to de-activate the vacuum gripper
        vacuum_Gripper = rospy.ServiceProxy(vacuumGripperService,
                                            vacuumGripper)
        # Sending the service call throough a try - catch block so that
        # a failure to call will be intimated to the user
        try:
            resp = vacuum_Gripper(activate_vacuum_gripper=False)
            scene.remove_attached_object(eef_link, name=box_name)
            scene.remove_world_object(box_name)
        except rospy.ServiceException as exc:
            print("Service did not process request: " + str(exc))
        print("\nVacuum gripper de-activated.\n")

        # We wait for the planning scene to update.
        return self.wait_for_state_update(box_is_known=True,
                                          box_is_attached=False,
                                          timeout=timeout)

    # Destructor
    def __del__(self):
        moveit_commander.roscpp_shutdown()
        rospy.loginfo(
            '\033[94m' + "Object of class Ur5Moveit Deleted." + '\033[0m')


def main():
    # Creating the server object and adding a box to it
    ur5 = Ur5Moveit()
    ur5.add_box()

    # Setting the initial joint angles of the robot
    lst_joint_angles_1 = [math.radians(0),
                          math.radians(0),
                          math.radians(0),
                          math.radians(0),
                          math.radians(0),
                          math.radians(0)]
    # Creating an object of Pose to define the pickup position/pose coordinates
    ur5_pose_pickUp = geometry_msgs.msg.Pose()
    ur5_pose_pickUp.position.x = 0.000284691349605
    ur5_pose_pickUp.position.y = 0.24300000
    ur5_pose_pickUp.position.z = 1.91216984427
    ur5_pose_pickUp.orientation.x = 0.02700
    ur5_pose_pickUp.orientation.y = 0.001
    ur5_pose_pickUp.orientation.z = -0.02700
    ur5_pose_pickUp.orientation.w = 0.999

    # Creating an object of Pose to define the drop position/pose coordinates
    ur5_pose_drop = geometry_msgs.msg.Pose()
    ur5_pose_drop.position.x = -0.737431349206
    ur5_pose_drop.position.y = -0.1741612805
    ur5_pose_drop.position.z = 1.04107191
    ur5_pose_drop.orientation.x = -0.027
    ur5_pose_drop.orientation.y = 0.001
    ur5_pose_drop.orientation.z = 0.027
    ur5_pose_drop.orientation.w = 0.999

    # Setting up the robot - adding its joints
    ur5.set_joint_angles(lst_joint_angles_1)
    rospy.sleep(5)

    # Calling a function to go to the pickup position/pose
    ur5.go_to_pose(ur5_pose_pickUp)
    # Attaching the box to the vacuum gripper
    ur5.attach_box()
    rospy.sleep(2)

    # Moving to the drop position to drop the box
    # and then detach it from the vacuum gripper
    ur5.go_to_pose(ur5_pose_drop)
    ur5.detach_and_remove_box()
    rospy.sleep(2)

    # Moving back to the initial position of the robot arm
    ur5.set_joint_angles(lst_joint_angles_1)
    rospy.sleep(2)

    # Deleting the server object as the work is done!
    del ur5
    rospy.loginfo("\nObjective achieved successfully!\n")


if __name__ == '__main__':
    main()
