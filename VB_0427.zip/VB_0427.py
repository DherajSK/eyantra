#!/usr/bin/env python

import rospy
import math

from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

#  Global Variables
initialTheta = None
current_angle = None


def rotate():
    #  Starts a new node
    rospy.init_node('node_turtle_revolve', anonymous=True)
    velocity_publisher = rospy.Publisher(
                       '/turtle1/cmd_vel',
                       Twist, queue_size=100)
    vel_msg = Twist()

    #  Setting the angular speed
    speed = 1
    vel_msg.angular.z = speed

    #  Setting all the linear components and
    #    1.5 as multiplier just to get a bigger circle
    vel_msg.linear.x = speed * 1.5
    vel_msg.linear.y = 0
    vel_msg.linear.z = 0
    vel_msg.angular.x = 0
    vel_msg.angular.y = 0
    #  Setting up initialTheta and current_angle variables
    #    to be used in the function
    global initialTheta, current_angle
    #  Initiating a subscriber to set initialTheta position
    #    and check for the end position
    rospy.Subscriber("/turtle1/pose", Pose, printOutCords)

    while(True):
        velocity_publisher.publish(vel_msg)
        if (rospy.is_shutdown()):
            break
        if((not (initialTheta is None))):
            #  It seems that this formula/condition for
                #    the least margin of error works for near all speeds
            if(round(abs(round(current_angle, 4) - round(initialTheta, 4)), 4)
               < speed * 0.01 and (current_angle != initialTheta)):
                #  Forcing the turtle to stop since it is almost at
                #    the initialTheta position
                vel_msg.angular.z = 0
                vel_msg.linear.x = 0
                velocity_publisher.publish(vel_msg)
                break


def printOutCords(msg):
    global initialTheta, current_angle
    #  Setting the initial theta value
    if(initialTheta is None):
        initialTheta = msg.theta
    current_angle = msg.theta
    rospy.loginfo("Theta :{}".format(msg.theta))


if __name__ == '__main__':
    try:
        #  Testing our function
        rotate()
    except rospy.ROSInterruptException:
        pass
