#!/usr/bin/python
# -*- coding: utf-8 -*-

import rospy
import sys
import copy
import math

import moveit_commander
import moveit_msgs.msg
import geometry_msgs.msg
import actionlib
from hrwros_gazebo.msg import LogicalCameraImage
from pkg_vb_sim.srv import conveyorBeltPowerMsg
from pkg_vb_sim.srv import conveyorBeltPowerMsgRequest
from pkg_vb_sim.srv import conveyorBeltPowerMsgResponse

from pkg_vb_sim.srv import vacuumGripper
from pkg_vb_sim.srv import vacuumGripperRequest
from pkg_vb_sim.srv import vacuumGripperResponse

i = 0
doingTask = False
done = False
p_list = []
to_go_pose = geometry_msgs.msg.Pose()
to_go_pose.position.x = -0.8
to_go_pose.position.y = -0.1
to_go_pose.position.z = 1 + 0.115 + 0.15 / 2

# This to keep EE parallel to Ground Plane

to_go_pose.orientation.x = -0.5
to_go_pose.orientation.y = -0.5
to_go_pose.orientation.z = 0.5
to_go_pose.orientation.w = 0.5
current_box = ''


class CartesianPath:

    # Constructor

    def __init__(self):

        rospy.init_node('node_eg5_waypoints', anonymous=True)

        self._planning_group = 'ur5_1_planning_group'
        self._commander = moveit_commander.roscpp_initialize(sys.argv)
        self._robot = moveit_commander.RobotCommander()
        self._scene = moveit_commander.PlanningSceneInterface()
        self._group = \
            moveit_commander.MoveGroupCommander(self._planning_group)
        self._display_trajectory_publisher = \
            rospy.Publisher('/move_group/display_planned_path',
                            moveit_msgs.msg.DisplayTrajectory,
                            queue_size=1)

        self._exectute_trajectory_client = \
            actionlib.SimpleActionClient('execute_trajectory',
                moveit_msgs.msg.ExecuteTrajectoryAction)
        self._exectute_trajectory_client.wait_for_server()

        self._planning_frame = self._group.get_planning_frame()
        self._eef_link = self._group.get_end_effector_link()
        self._group_names = self._robot.get_group_names()

        rospy.loginfo('\033[94m' + ' >>> Init done.' + '\033[0m')

    def set_joint_angles(self, arg_list_joint_angles):

        self._group.set_joint_value_target(arg_list_joint_angles)
        self._group.plan()
        flag_plan = self._group.go(wait=True)
        if flag_plan:
            rospy.loginfo('\033[94m' + '>>> set_joint_angles() Success'
                          + '\033[0m')
        else:
            rospy.logerr('\033[94m' + '>>> set_joint_angles() Failed.'
                         + '\033[0m')

        return flag_plan

    def wait_for_state_update(
        self,
        box_is_known=False,
        box_is_attached=False,
        timeout=4,
        ):
        box_name = ''
        scene = self._scene
        start = rospy.get_time()
        seconds = rospy.get_time()
        while seconds - start < timeout and not rospy.is_shutdown():

            # Test if the box is in attached objects

            attached_objects = scene.get_attached_objects([box_name])
            is_attached = len(attached_objects.keys()) > 0

        # Test if the box is in the scene.
        # Note that attaching the box will remove it from known_objects

            is_known = box_name in scene.get_known_object_names()

        # Test if we are in the expected state

            if box_is_attached == is_attached and box_is_known \
                == is_known:
                return True

        # Sleep so that we give other threads time on the processor

            rospy.sleep(0.1)
            seconds = rospy.get_time()

    # If we exited the while loop without returning then we timed out

        return False

    def attach_box(self, timeout=1, box_name=''):

        # Now we need to attach the box to the vacuum gripper

        box_name = box_name
        robot = self._robot
        scene = self._scene
        eef_link = self._eef_link
        group_names = self._group_names
        grasping_group = 'ur5_1_planning_group'
        touch_links = robot.get_link_names(group=grasping_group)
        scene.attach_box(eef_link, box_name, touch_links=touch_links)

        # Vacuum Gripper service to activate the gripper

        vacuumGripperService = '/eyrc/vb/ur5_1/activate_vacuum_gripper'

        # Waiting for the vacuum gripper service to become active

        rospy.wait_for_service(vacuumGripperService)

        # Creating a object of vacuumGripper service (message) to
        # call the service with the message to activate the vacuum gripper

        vacuum_Gripper = rospy.ServiceProxy(vacuumGripperService,
                vacuumGripper)

        # Sending the service call through a try - catch block so that
        # a failure to call will be intimated to the user

        try:
            resp = vacuum_Gripper(activate_vacuum_gripper=True)
        except rospy.ServiceException, exc:
            print 'Service did not process request: ' + str(exc)
        print '''
Vacuum gripper activated.
'''

        # We wait for the planning scene to update.

        return self.wait_for_state_update(box_is_attached=True,
                box_is_known=False, timeout=timeout)

    def detach_and_remove_box(self, timeout=1, box_name=''):
        box_name = box_name
        scene = self._scene
        eef_link = self._eef_link

        # Vacuum Gripper service to deactivate the gripper

        vacuumGripperService = '/eyrc/vb/ur5_1/activate_vacuum_gripper'

        # Waiting for the vacuum gripper service to become active

        rospy.wait_for_service(vacuumGripperService)

        # Creating a object of vacuumGripper service (message) to
        # call the service with the message to deactivate the vacuum gripper

        vacuum_Gripper = rospy.ServiceProxy(vacuumGripperService,
                vacuumGripper)

        # Sending the service call throough a try - catch block so that
        # a failure to call will be intimated to the user

        try:
            resp = vacuum_Gripper(activate_vacuum_gripper=False)
            scene.remove_attached_object(eef_link, name=box_name)
            scene.remove_world_object(box_name)
        except rospy.ServiceException, exc:
            print 'Service did not process request: ' + str(exc)
        print '''
Vacuum gripper de-activated.
'''

        # We wait for the planning scene to update.

        return self.wait_for_state_update(box_is_attached=True,
                box_is_known=False, timeout=timeout)

    def go_to_pose(self, arg_pose):
        global s
        pose_values = self._group.get_current_pose().pose
        self._group.set_pose_target(arg_pose)
        flag_plan = self._group.go(wait=True)  # wait=False for Async Move
        pose_values = self._group.get_current_pose().pose
        list_joint_values = self._group.get_current_joint_values()

        if flag_plan == True:
            rospy.loginfo('\033[94m' + '>>> go_to_pose() Success'
                          + '\033[0m')
        else:
            rospy.logerr('\033[94m'
                         + '>>> go_to_pose() Failed. Solution for Pose not Found.'
                          + '\033[0m')

        return flag_plan

    def move_conveyor(self, msg, timeout=1):
        conveyorService = '/eyrc/vb/conveyor/set_power'

        # Waiting for the vacuum gripper service to become active

        rospy.wait_for_service(conveyorService)

        # Creating a object of vacuumGripper service (message) to
        # call the service with the message to activate the vacuum gripper

        toggle_conveyor = rospy.ServiceProxy(conveyorService,
                conveyorBeltPowerMsg)

        # Sending the service call throough a try - catch block so that
        # a failure to call will be intimated to the user

        try:
            resp = toggle_conveyor(power=msg)
        except rospy.ServiceException, exc:
            print 'Service did not process request: ' + str(exc)
        if msg == 0:
            print '''
Stopping the conveyer....
'''
        else:
            print '''
Moving the conveyer....
'''
        rospy.sleep(0.1)

    # Function to pick up and place the box in the  respective container

    def do_pick_at_pose(self):

        # Declare global variables to set current operation state

        global to_go_pose, i, done, doingTask, current_box

        # Set current operation so that function will not
        # execute unnecessarily

        doingTask = True

        # Stopping the conveyor, moving the EE to the pickup
        # pose and attaching it to the vacuum gripper

        self.move_conveyor(0)
        self.go_to_pose(to_go_pose)
        self.attach_box()

        # Go to the appropriate pose to drop boxes into the resp. baskets

        if current_box == 'packagen1':
            to_go_pose.position.x = 0
            to_go_pose.position.y = 0.75
            to_go_pose.position.z = 1.5
            self.set_joint_angles([
                1.4,
                -1.3,
                1.2,
                -1.5,
                -1.6,
                -1.7,
                ])

        if current_box == 'packagen2':
            to_go_pose.position.x = 0.6
            to_go_pose.position.y = 0
            to_go_pose.position.z = 1.5
            self.set_joint_angles([
                -0.226,
                -0.862,
                1.154,
                -0.2915,
                -0.226,
                0,
                ])

        if current_box == 'packagen3':
            to_go_pose.position.x = 0
            to_go_pose.position.y = -0.6
            to_go_pose.position.z = 1.5
            self.set_joint_angles([
                1.8,
                -2.12,
                -1.47,
                0.218,
                1.6,
                1.8,
                ])

        # Remove the box and drop it

        self.detach_and_remove_box()

        # Move the conveyor and check if all boxes then
        # are dropped else increment the 'i' value

        self.move_conveyor(80)
        if i >= 2:
            done = True
        i += 1
        doingTask = False

    # Call back function to check the coordinates of the box through the
    # logical camera and then convey it to the main through doingTask

    def callback_cam(self, cam):
        global done, i, doingTask, current_box

        # Looping through all items detected by the logical camera

        for k in cam.models:
            if k.type != 'ur5' and k.pose.position.y < 0.02 \
                and not done and not doingTask:
                to_go_pose.position.x = -0.8 + k.pose.position.z
                to_go_pose.position.y = k.pose.position.y - 0.05
                to_go_pose.position.z = 1.19
                doingTask = True
                current_box = k.type
                break

    # Destructor

    def __del__(self):
        moveit_commander.roscpp_shutdown()
        rospy.loginfo('\033[94m'
                      + 'Object of class CartesianPath Deleted.'
                      + '\033[0m')


def main():
    ur5 = CartesianPath()

    # Moving the arm to initial position

    ur5.set_joint_angles([
        3.011983345328397,
        -0.6997527171486469,
        1.0169972921609514,
        -1.8875420987931326,
        -1.5700252149103697,
        -0.1366450415505449,
        ])
    global doingTask

    rospy.Subscriber('/eyrc/vb/logical_camera_2', LogicalCameraImage,
                     ur5.callback_cam, queue_size=1)

    # Starting the conveyor

    ur5.move_conveyor(80)

    while not rospy.is_shutdown():
        if doingTask:
            ur5.do_pick_at_pose()
        if done:
            break
        pass
    ur5.move_conveyor(0)
    del ur5


if __name__ == '__main__':
    main()
